output "collection_endpoint" {
  value = aws_opensearchserverless_collection.this.collection_endpoint
}

output "dashboard_endpoint" {
  value = aws_opensearchserverless_collection.this.dashboard_endpoint
}

output "collection_arn" {
  value = aws_opensearchserverless_collection.this.arn
}