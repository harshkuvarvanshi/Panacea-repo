include {
  path = find_in_parent_folders("root.hcl")
}

inputs = {
  environment = "dev"
}