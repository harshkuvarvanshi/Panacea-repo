############################
# S3 Bucket (State)
############################
resource "aws_s3_bucket" "state" {
  bucket = var.bucket_name

  #lifecycle {
   # prevent_destroy = true
  #}

  tags = {
    Name = var.bucket_name
  }
}

############################
# Versioning
############################
resource "aws_s3_bucket_versioning" "state" {
  bucket = aws_s3_bucket.state.id

  versioning_configuration {
    status = "Enabled"
  }
}

############################
# Encryption
############################
resource "aws_s3_bucket_server_side_encryption_configuration" "state" {
  bucket = aws_s3_bucket.state.id

  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

############################
# Block Public Access
############################
resource "aws_s3_bucket_public_access_block" "state" {
  bucket = aws_s3_bucket.state.id

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

############################
# DynamoDB Lock Table
############################
resource "aws_dynamodb_table" "locks" {
  name         = var.lock_table_name
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "LockID"

  attribute {
    name = "LockID"
    type = "S"
  }

  #lifecycle {
  #  prevent_destroy = true
  #}
}